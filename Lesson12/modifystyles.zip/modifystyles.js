function applyChanges(){
    document.body.style.background = document.getElementById("backgroundColor").value;
    document.body.style.color = document.getElementById("textColor").value;
    document.body.style.fontFamily = document.getElementById("font").value;
    document.body.style.fontSize = document.getElementById("size").value;
}